﻿//using Microsoft.AspNetCore.Mvc;

//namespace WebApplication8API.Controllers
//{
//    [ApiController]
//    [Route("Login")]
//    public class LoginController : Controller
//    {
//        //[HttpPost("Login")]
//        //public async Task<>
//        //{
//        //    return View();
//        //}
//    }
//}