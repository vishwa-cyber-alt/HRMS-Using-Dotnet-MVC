﻿using WebApplication8.Models;

namespace WebApplication8
{
    public class Static
    {
        public static LoginModel UserData { get; set; }
    }
}
