using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApplication8.Models;

namespace WebApplication8.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            ViewBag.Salary = Static.UserData.Salary;
            ViewBag.UserID = Static.UserData.UserId;
            ViewBag.Role = Static.UserData.Role;
            ViewBag.Leave = Static.UserData.Leave;
            ViewBag.UserName = Static.UserData.Username;
            return View();
        } 
        public IActionResult LeaveApply()
        {
            return View();
        }
        public IActionResult Error()
        {
            return View();
        }
        public IActionResult Manager()
        {
            ViewBag.Salary = Static.UserData.Salary;
            ViewBag.UserID = Static.UserData.UserId;
            ViewBag.Role = Static.UserData.Role;
            ViewBag.Leave = Static.UserData.Leave;
            ViewBag.UserName = Static.UserData.Username;
            return View();
        }
       
    }
}
