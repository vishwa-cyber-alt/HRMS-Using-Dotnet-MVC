﻿using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using WebApplication8.Models;

using Microsoft.AspNetCore.Mvc;
using Dapper;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Globalization;
using System.Reflection;

namespace WebApplication8.Controllers
{
    public class LoginController : Controller
    {
        private string connectionString = "Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True";    
        public ActionResult Index()
        {
            if (Static.UserData != null)
            {
                ViewBag.Salary = Static.UserData.Salary;
                ViewBag.UserID = Static.UserData.UserId;
                ViewBag.Role = Static.UserData.Role;
                ViewBag.Leave = Static.UserData.Leave;
                ViewBag.UserName = Static.UserData.Username;
                ViewBag.FirstName = Static.UserData.FirstName;
                ViewBag.LastName = Static.UserData.LastName;
                ViewBag.Email = Static.UserData.Email;
                ViewBag.PhoneNumber = Static.UserData.PhoneNumber;
                ViewBag.Password = Static.UserData.Password;
                ViewBag.LeaveType = Static.UserData.LeaveType;
                return View();
            }
            else
            {
                return View("~/Views/Home/Index.cshtml");
            }
        }

        [HttpPost]
        public IActionResult Login(LoginModel model)
        {
            var result = Repo.Login(model);
            Static.UserData = result;
            if (result == null)
            {
                return RedirectToAction("Index", "Login", new { error = "Invalid username or password." });
            }
            switch (result.Role)
            {
                case "User":
                    return RedirectToAction("Index", "Login", new { UserName = model.Username, Password = model.Password });
                case "Admin":
                    return RedirectToAction("Privacy", "Home", new { UserName = model.Username });
                case "Manager":
                    return RedirectToAction("Manager", "Home", new { UserName = model.Username });
                default:
                    return RedirectToAction("Index", "Home");
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetData(string role)
        {
            var response = await Repo.GetData(role);
            return Ok(response);
        }
        public async Task<List<LoginModel>> GetUpcomingHolidays()
        {
            var response = await Repo.GetUpcomingHolidays();
            return response;
        }
        public async Task<List<LoginModel>> GetEvent()
        {
            var response = await Repo.GetEvent();
            return response;
        }
        public async Task<List<LoginModel>> GetAllUsersTask()
        {
            var response = await Repo.GetAllUsersTask();
            return response;
        }
        public async Task<List<LoginModel>> LoadLeaveBalance(int userId)
        {
            var response = await Repo.LoadLeaveBalance(userId);
            return response;
        }
        public async Task<int> GetLossofPayCount(int userId)
        {
            var count = await Repo.GetLossofPayCount(userId);
            return count;
        }

        //public async Task<string> LeaveApply(LoginModel data)
        //{
        //    DateTime startDate = data.StartDate;
        //    DateTime endDate = data.EndDate;
        //    var leaveDays = (endDate - startDate).Days + 1;
        //    data.Leave = leaveDays;

        //    var response = await Repo.LeaveApply(data);
        //    return response;
        //}
        public async Task<string> LeaveApply(LoginModel data)
        {
            DateTime startDate = data.StartDate;
            DateTime endDate = data.EndDate;
            var leaveDays = (endDate - startDate).Days + 1; // Calculate leave days
            data.Leave = leaveDays; // Pass the leave days to the model

            var response = await Repo.LeaveApply(data);
            return response;
        }

        public async Task<List<LoginModel>> GetLeaveRequests()
        {
            var response = await Repo.GetLeaveRequests();
            return response;
        }
        public async Task<List<LoginModel>> GetLeaveHistory(int userId)
        {
            var response = await Repo.GetLeaveHistory(userId);
            return response;
        }
        public IActionResult Register(LoginModel data)
        {
            var response = Repo.Register(data);
            if (response != 0)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return RedirectToAction("Register", "Home");
            }
        }
        public async Task<int> ApproveLeave(int leaveApplyId, string Status, string AuthorizeBy)
        {
            var response = await Repo.ApproveLeave(leaveApplyId, Status, AuthorizeBy);
            return response;
        }
        public IActionResult GiveLeave(LoginModel data)
        {
            var response = Repo.GiveLeave(data);
            if (response != 0)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return RedirectToAction("Register", "Home");
            }
        }
        //public IActionResult AssignRole(LoginModel data)
        //{
        //    var response = Repo.AssignRole(data);
        //    if (response != 0)
        //    {
        //        return RedirectToAction("Index", "Home");
        //    }
        //    else
        //    {
        //        return RedirectToAction("Register", "Home");
        //    }
        //}
        public IActionResult AssignRole(LoginModel data)
        {
            var response = Repo.AssignRole(data);
            if (response != 0)
            {
                // Returning success status as JSON (useful for AJAX handling)
                return Json(new { success = true, message = "Role assigned successfully!" });
            }
            else
            {
                // Returning error status as JSON
                return Json(new { success = false, message = "Role assignment failed." });
            }
        }

        public IActionResult IncrementSalary(LoginModel data,string Manager)
           
        {
            var response = Repo.IncrementSalary(data,Manager);
            if (response != 0)
            {
                return RedirectToAction("Index", "Home");
            }
            else
            {
                return RedirectToAction("Register", "Home");
            }
        }
        public async Task<string> ChangePassword(string password, int userId, string username)
        {
            var response = await Repo.ChangePassword(password, userId, username);
            var result = "Password Change Successful..";
            return result;
        }
        public async Task<List<LoginModel>> GetUsernameDropDown()
        {
            var response = await Repo.GetUsernameDropDown();
            return response;
        }
        public async Task<List<LoginModel>> LoadLeaveUsernameDropdown()
        {
            var response = await Repo.LoadLeaveUsernameDropdown();
            return response;
        } 
        public async Task<List<LoginModel>> LoadSalaryUsernameDropdown()
        {
            var response = await Repo.LoadSalaryUsernameDropdown();
            return response;
        }
        public async Task<List<LoginModel>> LoadStatusUsernameDropdown()
        {
            var response = await Repo.LoadStatusUsernameDropdown();
            return response;
        }
        public async Task<List<LoginModel>> LoadRoleDropdown()
        {
            var response = await Repo.LoadRoleDropdown();
            return response;
        }
        public async Task<List<LoginModel>> LoadComplaintUsernameDropdown()
        {
            var response = await Repo.LoadComplaintUsernameDropdown();
            return response;
        }
        public ActionResult PaySlip()
        {
            ViewBag.Salary = Static.UserData.Salary;
            ViewBag.UserID = Static.UserData.UserId;
            ViewBag.Role = Static.UserData.Role;
            ViewBag.Leave = Static.UserData.Leave;
            ViewBag.UserName = Static.UserData.Username;
            ViewBag.Password = Static.UserData.Password;
            return View();

        }
        public async Task<List<LoginModel>> GetHike(int userid)
        {
            var response = await Repo.GetHike(userid);
            return response;
        }
        public async Task<List<LoginModel>> GetComp(int userid)
        {
            var response = await Repo.GetComp(userid);
            return response;
        }
          public async Task<List<LoginModel>> GetTask(int userid)
        {
            var response = await Repo.GetTask(userid);
            return response;
        }

      
        public async Task<IActionResult> Update(LoginModel data, int userid)
        {
            var response = await Repo.Update(data, userid);
            var result = "employee Updated Successfully...!";
            return Json(result);
        }
        public async Task<IActionResult> AddTask(LoginModel data, int userid)
        {
            try
            {
                var response = await Repo.AddTask(data, userid);
                var result = "Task Added Successfully!";
                return Json(result);
            }
            catch (Exception ex)
            {
                return Json(new { error = true, message = ex.Message });
            }
        }

        public async Task<LoginModel> GetSingleUsers(int TaskID)
        {
            var response = await Repo.GetSingleUsers(TaskID);
            return response;
        }

        public async Task<IActionResult> UpdateTask(int TaskID, string TaskName, string DueDate)
        {
            var response = await Repo.UpdateTask(TaskID, TaskName, DueDate);
            var result = response == "Success" ? "Task Updated Successfully!" : "Failed to update the task.";
            return Json(result);
        }

        public async Task<IActionResult> Delete(int TaskID)
        {
            var response = await Repo.Delete(TaskID);
            var result = "Employee Deleted Successfully...!";
            return Json(result);
        }
        public async Task<IActionResult> AddCalender(LoginModel data, string Manager)
        {
            try
            {
                var response = await Repo.AddCalender(data, Manager);
                var result = "Calender Added Successfully!";
                return Json(result);
            }
            catch (Exception ex)
            {
                return Json(new { error = true, message = ex.Message });
            }
        }
        public async Task<IActionResult> PostUpdate(LoginModel data)
        {
            try
            {
                var response = await Repo.PostUpdate(data);
                var result = "Calender Added Successfully!";
                return Json(result);
            }
            catch (Exception ex)
            {
                return Json(new { error = true, message = ex.Message });
            }
        }
        public async Task<IActionResult> UserStatus(LoginModel data)
        {
            try
            {
                var response = await Repo.UserStatus(data);
                var result = "Status Added Successfully!";
                return Json(result);
            }
            catch (Exception ex)
            {
                return Json(new { error = true, message = ex.Message });
            }
        }




        public async Task<IActionResult> RaiseComplaint(LoginModel data)
        {
            try
            {
                var response = await Repo.RaiseComplaint(data);
                var result = "Complaint Added Successfully!";   
                return Json(result);
            }
            catch (Exception ex)
            {
                return Json(new { error = true, message = ex.Message });
            }
        }

        public async Task<List<LoginModel>> GetUserStatus()
        {
            var response = await Repo.GetUserStatus();
            return response;
        }
        public async Task<List<LoginModel>> GetComplaints()
        {
            var response = await Repo.GetComplaints();
            return response;
        }
    }
}