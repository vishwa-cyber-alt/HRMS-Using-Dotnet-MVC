﻿using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Dapper;
using Microsoft.AspNetCore.Hosting.Server;
using WebApplication8.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;
namespace WebApplication8.Models
{
    public class Repo
    {
        public async static Task<List<LoginModel>> GetData(string role = null)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    string query = "SELECT * FROM Users";
                    if (!string.IsNullOrEmpty(role))
                    {
                        query += " WHERE Role = @Role";
                    }
                    var employees = await conn.QueryAsync<LoginModel>(query, new { Role = role });
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the employee list.", ex);
                }
            }
        }

        //public async static Task<List<LoginModel>> GetUpcomingHolidays()
        //{
        //    using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
        //    {
        //        try
        //        {
        //            await conn.OpenAsync();
        //            var employees = await conn.QueryAsync<LoginModel>("SELECT Top 1 * FROM Holidays");
        //            return employees.ToList();
        //        }
        //        catch (Exception ex)
        //        {
        //            throw new Exception("An error occurred while fetching the employee list.", ex);
        //        }
        //    }
        //}

        public async static Task<List<LoginModel>> GetUpcomingHolidays()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>("SELECT top 1 * FROM UpcomingHolidays WHERE HolidayDate > GETDATE() ORDER BY HolidayDate ASC;");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the holiday list.", ex);
                }
            }
        }

        public async static Task<List<LoginModel>> GetEvent()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>("SELECT * FROM Events");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the employee list.", ex);
                }
            }
        }
        public async static Task<List<LoginModel>> GetAllUsersTask()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>("select t.Taskname,t.DueDate,u.Username from Todo as t LEFT JOIN Users as u on t.UserId = u.UserId");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the employee list.", ex);
                }
            }
        }
        public async static Task<List<LoginModel>> LoadLeaveBalance(int userId)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>(
                        "SELECT Leave FROM Users WHERE UserId = @UserId",
                        new { UserId = userId }
                    );
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the leave balance.", ex);
                }
            }
        }
        public async static Task<List<LoginModel>> GetLeaveRequests()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>("SELECT * FROM LeaveApply");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the employee list.", ex);
                }
            }
        }
        //public static LoginModel Login(LoginModel model)
        //{
        //    using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
        //    {
        //        var query = "SELECT * FROM LeaveApply la,Users u WHERE la.UserId = u.UserId AND u.UserId = (SELECT UserId FROM Users WHERE Username = @Username AND Password = @Password);";
        //        var result = conn.QueryFirstOrDefault<LoginModel>(query, new
        //        {
        //            Username = model.Username,
        //            Password = model.Password,
        //        }, commandType: CommandType.Text);
        //        return result;
        //    }   
        //}
        public static LoginModel Login(LoginModel model)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                var query = "SELECT * FROM Users WHERE Username = @Username AND Password = @Password";
                var result = conn.QueryFirstOrDefault<LoginModel>(query, new
                {
                    Username = model.Username,
                    Password = model.Password,
                }, commandType: CommandType.Text);
                return result;
            }
        }

        public static int Register(LoginModel data)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    var checkQuery = "SELECT COUNT(1) FROM Users WHERE Username = @Username";
                    var userExists = conn.ExecuteScalar<int>(checkQuery, new { Username = data.Username });

                    if (userExists > 0)
                    {
                        return 0; 
                    }

                   
                    var query = "INSERT INTO Users (Role, Username, Password, Salary, Leave, FirstName, LastName, Email, PhoneNumber) VALUES (@Role, @Username, @Password, @Salary, @Leave, @FirstName, @LastName, @Email, @PhoneNumber)";
                    var response = conn.Execute(query, new
                    {
                        Role = "User",
                        Username = data.Username,
                        Password = data.Password,
                        Salary = "5000",
                        Leave = "2",
                        FirstName = data.FirstName,
                        LastName = data.LastName,
                        Email = data.Email,
                        PhoneNumber = data.PhoneNumber,
                    }, commandType: CommandType.Text);

                    return 1; 
                }
                catch (Exception ex)
                {
                    
                    return 0;
                }
            }
        }

        //public static async Task<string> LeaveApply(LoginModel data)
        //{
        //    string connectionString = "Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;";
        //    var insertQuery = "INSERT INTO LeaveApply (UserId, Username, LeaveType, StartDate, EndDate, Reason,Status,Visited) " +
        //                      "VALUES (@UserId, @Username, @LeaveType, @StartDate, @EndDate, @Reason,@Status,@Visited);";
        //    var updateQuery = "UPDATE Users SET Leave = Leave - @Leave WHERE UserId = @UserId AND Leave >= @Leave;";
        //    var parameters = new DynamicParameters();
        //    parameters.Add("@UserId", data.UserId);
        //    parameters.Add("@Username", data.Username);
        //    parameters.Add("@LeaveType", data.LeaveType);
        //    parameters.Add("@StartDate", data.StartDate);
        //    parameters.Add("@EndDate", data.EndDate);
        //    parameters.Add("@Reason", data.Reason);
        //    parameters.Add("@Status", "Pending");
        //    parameters.Add("@Visited", false);
        //    var leaveUpdateParameters = new DynamicParameters();
        //    leaveUpdateParameters.Add("@UserId", data.UserId);
        //    leaveUpdateParameters.Add("@Leave", data.Leave);

        //    using (SqlConnection conn = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            await conn.OpenAsync();
        //            using (var transaction = conn.BeginTransaction())
        //            {
        //                await conn.ExecuteAsync(insertQuery, parameters, transaction: transaction, commandType: CommandType.Text);
        //                var rowsAffected = await conn.ExecuteAsync(updateQuery, leaveUpdateParameters, transaction: transaction, commandType: CommandType.Text);
        //                if (rowsAffected == 0)
        //                {
        //                    transaction.Rollback();
        //                    return "failed. Not enough leave balance.";
        //                }
        //                transaction.Commit();
        //                return "Leave application successfully submitted and leave count updated.";
        //            }
        //        }
        //        catch (SqlException ex)
        //        {
        //            return $"SQL Error: {ex.Message}";
        //        }
        //        catch (Exception ex)
        //        {
        //            return $"Error: {ex.Message}";
        //        }
        //    }
        //}
        //public static async Task<string> LeaveApply(LoginModel data)
        //{
        //    string connectionString = "Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;";
        //    var insertQuery = "INSERT INTO LeaveApply (UserId, Username, LeaveType, StartDate, EndDate, Reason, Status, Visited) " +
        //                      "VALUES (@UserId, @Username, @LeaveType, @StartDate, @EndDate, @Reason, @Status, @Visited);";
        //    var updateQuery = "UPDATE Users SET Leave = Leave - @Leave WHERE UserId = @UserId AND Leave >= @Leave;";

        //    var parameters = new DynamicParameters();
        //    parameters.Add("@UserId", data.UserId);
        //    parameters.Add("@Username", data.Username);
        //    parameters.Add("@LeaveType", data.LeaveType);
        //    parameters.Add("@StartDate", data.StartDate);
        //    parameters.Add("@EndDate", data.EndDate);
        //    parameters.Add("@Reason", data.Reason);
        //    parameters.Add("@Status", "Pending");
        //    parameters.Add("@Visited", false);

        //    var leaveUpdateParameters = new DynamicParameters();
        //    leaveUpdateParameters.Add("@UserId", data.UserId);
        //    leaveUpdateParameters.Add("@Leave", data.Leave); // Pass the leaveDays to this parameter

        //    using (SqlConnection conn = new SqlConnection(connectionString))
        //    {
        //        try
        //        {
        //            await conn.OpenAsync();
        //            using (var transaction = conn.BeginTransaction())
        //            {
        //                await conn.ExecuteAsync(insertQuery, parameters, transaction: transaction, commandType: CommandType.Text);
        //                var rowsAffected = await conn.ExecuteAsync(updateQuery, leaveUpdateParameters, transaction: transaction, commandType: CommandType.Text);

        //                if (rowsAffected == 0)
        //                {
        //                    transaction.Rollback();
        //                    return "Failed. Not enough leave balance.";
        //                }
        //                transaction.Commit();
        //                return "Leave application successfully submitted and leave count updated.";
        //            }
        //        }
        //        catch (SqlException ex)
        //        {
        //            return $"SQL Error: {ex.Message}";
        //        }
        //        catch (Exception ex)
        //        {
        //            return $"Error: {ex.Message}";
        //        }
        //    }
        //}
        public static async Task<string> LeaveApply(LoginModel data)
        {
            string connectionString = "Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;";

            // Check leave balance first
            var checkBalanceQuery = "SELECT Leave FROM Users WHERE UserId = @UserId";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    await conn.OpenAsync();

                    // Get the current leave balance
                    var currentBalance = await conn.ExecuteScalarAsync<int>(checkBalanceQuery, new { UserId = data.UserId });

                    // If the user does not have enough leave balance, return an error message
                    if (currentBalance < data.Leave)
                    {
                        return "Insufficient leave balance.";
                    }

                    var insertQuery = "INSERT INTO LeaveApply (UserId, Username, LeaveType, StartDate, EndDate, Reason, Status,AuthorizeBy, Visited) " +
                                      "VALUES (@UserId, @Username, @LeaveType, @StartDate, @EndDate, @Reason, @Status,@AuthorizeBy, @Visited);";

                    var updateQuery = "UPDATE Users SET Leave = Leave - @Leave WHERE UserId = @UserId AND Leave >= @Leave;";

                    var parameters = new DynamicParameters();
                    parameters.Add("@UserId", data.UserId);
                    parameters.Add("@Username", data.Username);
                    parameters.Add("@LeaveType", data.LeaveType);
                    parameters.Add("@StartDate", data.StartDate);
                    parameters.Add("@EndDate", data.EndDate);
                    parameters.Add("@Reason", data.Reason);
                    parameters.Add("@Status", "Pending");
                    parameters.Add("@AuthorizeBy", "Pending");
                    parameters.Add("@Visited", false);

                    var leaveUpdateParameters = new DynamicParameters();
                    leaveUpdateParameters.Add("@UserId", data.UserId);
                    leaveUpdateParameters.Add("@Leave", data.Leave); 

                    using (var transaction = conn.BeginTransaction())
                    {
                        // Insert the leave application
                        await conn.ExecuteAsync(insertQuery, parameters, transaction: transaction);

                        // Update the leave balance
                        var rowsAffected = await conn.ExecuteAsync(updateQuery, leaveUpdateParameters, transaction: transaction);

                        if (rowsAffected == 0)
                        {
                            transaction.Rollback();
                            return "Failed. Not enough leave balance.";
                        }

                        transaction.Commit();
                        return "Leave application successfully submitted and leave count updated.";
                    }
                }
                catch (SqlException ex)
                {
                    return $"SQL Error: {ex.Message}";
                }
                catch (Exception ex)
                {
                    return $"Error: {ex.Message}";
                }
            }
        }

        public async static Task<List<LoginModel>> GetLeaveHistory(int userId)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>(
                        "SELECT * FROM LeaveApply WHERE UserId = @UserId", new { UserId = userId });
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the leave history.", ex);
                }
            }
        }
        public static async Task<int> ApproveLeave(int leaveApplyId, string Status,string AuthorizeBy)
        {
            using (var conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    var updateQuery = "UPDATE LeaveApply SET Status = @Status,Visited=@Visited,AuthorizeBy=@AuthorizeBy WHERE leaveApplyId = @leaveApplyId";
                    var result =  await conn.ExecuteAsync(updateQuery, new
                    {
                        leaveApplyId = leaveApplyId,
                        Status = Status,
                        Visited = true ,
                        AuthorizeBy= AuthorizeBy
                    }, commandType: CommandType.Text);
                    return 1;

                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while updating the leave status.", ex);
                    return 0;
                }
            }
        }
        public static int GiveLeave(LoginModel data)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    var query = "UPDATE Users SET Leave = Leave + @Leave WHERE UserId = @UserId";
                    var response = conn.Execute(query, new
                    {
                        
                        UserId = data.UserId,
                        Leave = data.Leave
                    }, commandType: CommandType.Text);
                    return 1; 
                }
                catch (Exception ex)
                {
                    return 0; 
                }
            }
        }
        public static async Task<string> ChangePassword(string password, int userId, string username)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                await conn.OpenAsync();
                var updateQuery = "UPDATE Users SET Password = @Password WHERE UserId = @UserId";
                var parameters = new DynamicParameters();
                parameters.Add("@Password", password);
                parameters.Add("@UserId", userId);
                int rowsAffected = await conn.ExecuteAsync(updateQuery, parameters);
                return rowsAffected > 0 ? "Password Change Successful." : "Password Change Failed.";
            }
        }
        //public static int AssignRole(LoginModel data)
        //{
        //    using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
        //    {
        //        try
        //        {
        //            var query = "UPDATE Users SET Role = @Role WHERE UserId = @UserId";
        //            var response = conn.Execute(query, new
        //            {
        //                UserId = data.UserId,
        //                Role = data.Role
        //            }, commandType: CommandType.Text);
        //            return 1;
        //        }
        //        catch (Exception ex)
        //        {
        //            return 0;
        //        }
        //    }
        //}
        public static int AssignRole(LoginModel data)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    var query = "UPDATE Users SET Role = @Role WHERE UserId = @UserId";
                    var response = conn.Execute(query, new
                    {
                        UserId = data.UserId,
                        Role = data.Role
                    }, commandType: CommandType.Text);

                    return response > 0 ? 1 : 0; 
                }
                catch (Exception ex)
                {
                    return 0; 
                }
            }
        }

        public async static Task<List<LoginModel>> GetUsernameDropDown()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>("SELECT  UserId,FirstName,LastName FROM Users  where Role<>'Manager'");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the username list.", ex);
                }
            }
        }
        public async static Task<List<LoginModel>> LoadLeaveUsernameDropdown()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>("SELECT UserId,FirstName,LastName FROM Users  where Role<>'Manager' AND Role <> 'Admin'");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the username list.", ex);
                }
            }
        }
        public async static Task<List<LoginModel>> LoadSalaryUsernameDropdown()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                        var employees = await conn.QueryAsync<LoginModel>("SELECT UserId,FirstName,LastName FROM Users  where Role<>'Manager' AND Role<>'Admin'");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the username list.", ex);
                }
            }
        }



        public async static Task<List<LoginModel>> LoadComplaintUsernameDropdown()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>("SELECT UserId,FirstName,LastName FROM Users  where Role<>'Manager' AND Role<>'Admin'");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the username list.", ex);
                }
            }
        }




        public async static Task<List<LoginModel>> LoadStatusUsernameDropdown()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>("SELECT UserId,FirstName,LastName FROM Users  where Role<>'Manager' AND Role<>'Admin'");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the username list.", ex);
                }
            }
        }


        public static int IncrementSalary(LoginModel data,string Manager)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    conn.Open();

                    // Step 1: Retrieve the old salary
                    var getOldSalaryQuery = "SELECT Salary FROM Users WHERE UserId = @UserId";
                    var oldSalary = conn.QuerySingleOrDefault<decimal>(getOldSalaryQuery, new { UserId = data.UserId });

                    // Step 2: Update the salary
                    var updateSalaryQuery = "UPDATE Users SET Salary = @Salary WHERE UserId = @UserId";
                    conn.Execute(updateSalaryQuery, new { UserId = data.UserId, Salary = data.Salary }, commandType: CommandType.Text);

                    // Step 3: Log the salary change
                    var logQuery = "INSERT INTO SalaryChangeLog (UserId, OldSalary, NewSalary, ChangeDate,Manager) VALUES (@UserId, @OldSalary, @NewSalary, @ChangeDate,@Manager)";
                    conn.Execute(logQuery, new
                    {
                        UserId = data.UserId,
                        OldSalary = oldSalary,
                        NewSalary = data.Salary,
                        ChangeDate = DateTime.Now,
                        Manager=Manager,
                        
                    }, commandType: CommandType.Text);

                    return 1;
                }
                catch (Exception ex)
                {
                    return 0;
                }
            }
        }
        public async static Task<List<LoginModel>> GetHike(int userid)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();

                    var updateQuery = "SELECT * FROM SalaryChangeLog WHERE UserId = @userId";

                    var result = await conn.QueryAsync<LoginModel>(updateQuery, new { userid = userid });

                    return result.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the hike list.", ex);
                }
            }
        }
        public async static Task<List<LoginModel>> LoadRoleDropdown()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>("SELECT distinct Role FROM Users");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the username list.", ex);
                }
            }
        }
        public static async Task<string> Update(LoginModel data, int userid)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                DynamicParameters parameters = new DynamicParameters();

                parameters.Add("@UserId", data.UserId);
                parameters.Add("@FirstName", data.FirstName);
                parameters.Add("@LastName", data.LastName);
                parameters.Add("@Email", data.Email);
                parameters.Add("@PhoneNumber", data.PhoneNumber);
                parameters.Add("@UserName", data.Username);
                parameters.Add("@Password", data.Password);
                return (await conn.ExecuteAsync("update Users set FirstName = @FirstName, LastName = @LastName, Email = @Email ,PhoneNumber=@PhoneNumber,Username=@UserName,Password=@Password where UserId= @userid", parameters)).ToString();
            }
        }
        public static async Task<string> AddTask(LoginModel data, int userid)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
                {
                    var query = "INSERT INTO Todo (TaskName, DueDate, UserId) VALUES (@TaskName, @DueDate, @UserId)";

                    var parameters = new DynamicParameters();
                    parameters.Add("@TaskName", data.TaskName);
                    parameters.Add("@DueDate", data.DueDate);
                    parameters.Add("@UserId", userid);

                    int rowsAffected = await conn.ExecuteAsync(query, parameters);
                    return rowsAffected.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Database error while adding task", ex);
            }
        }

        public async static Task<List<LoginModel>> GetTask(int userid)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();

                    var updateQuery = "SELECT * FROM Todo WHERE UserId = @userId";

                    var result = await conn.QueryAsync<LoginModel>(updateQuery, new { userid = userid });

                    return result.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the hike list.", ex);
                }
            }
        }
        public async static Task<LoginModel> GetSingleUsers(int TaskID)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                string query = "SELECT * FROM Todo WHERE TaskID = @TaskID";
                return (await conn.QueryFirstAsync<LoginModel>(query, new { TaskID }));
            }
        }

        public static async Task<string> UpdateTask(int TaskID, string TaskName, string DueDate)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@TaskID", TaskID);
                parameters.Add("@TaskName", TaskName);
                parameters.Add("@DueDate", DueDate);

                var rowsAffected = await conn.ExecuteAsync("UPDATE Todo SET TaskName = @TaskName, DueDate = @DueDate WHERE TaskID = @TaskID", parameters);
                return rowsAffected > 0 ? "Success" : "Failure";
            }
        }
        public static async Task<string> Delete(int TaskID)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                return (await conn.ExecuteAsync("delete from Todo where TaskID=" + TaskID + "")).ToString();
            }
        }
        public static async Task<string> AddCalender(LoginModel data,string Manager)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
                {
                    var query = "INSERT INTO Holidays (DateValue, HolidayName,Manager) VALUES (@DateValue, @HolidayName,@Manager)";

                    var parameters = new DynamicParameters();
                    parameters.Add("@DateValue", data.DateValue);
                    parameters.Add("@HolidayName", data.HolidayName);
                    parameters.Add("@Manager", data.Manager);

                    int rowsAffected = await conn.ExecuteAsync(query, parameters);
                    return rowsAffected.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Database error while adding task", ex);
            }
        }
        public static async Task<string> PostUpdate(LoginModel data)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
                {
                    var query = "INSERT INTO Events (EventName, EventDescription) VALUES (@EventName, @EventDescription)";

                    var parameters = new DynamicParameters();
                    parameters.Add("@EventName", data.EventName);
                    parameters.Add("@EventDescription", data.EventDescription);

                    int rowsAffected = await conn.ExecuteAsync(query, parameters);
                    return rowsAffected.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Database error while adding task", ex);
            }
        } 
        
        public static async Task<string> UserStatus(LoginModel data)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
                {
                    var query = "INSERT INTO UserStatus (EmpName, UserStatus) VALUES (@EmpName, @UserStatus)";

                    var parameters = new DynamicParameters();
                    parameters.Add("@EmpName", data.EmpName);
                    parameters.Add("@UserStatus", data.UserStatus);

                    int rowsAffected = await conn.ExecuteAsync(query, parameters);
                    return rowsAffected.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Database error while adding task", ex);
            }
        }
        public async static Task<int> GetLossofPayCount(int userId)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var count = await conn.ExecuteScalarAsync<int>(
                        "SELECT COUNT(LeaveType) FROM LeaveApply WHERE LeaveType = 'LossOfPay' AND UserId = @UserId",
                        new { UserId = userId }
                    );
                    return count;
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the leave balance.", ex);
                }
            }
        }


        public async static Task<List<LoginModel>> GetUserStatus()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>("SELECT Username, t1.UserStatus FROM     UserStatus t1 JOIN  Users t2 ON     t1.EmpName = t2.UserId;");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the employee list.", ex);
                }
            }
        }










        public static async Task<string> RaiseComplaint(LoginModel data)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
                {
                    var query = "INSERT INTO Complaints (Name, ComplaintReason,EmployeeName) VALUES (@Name, @ComplaintReason,@EmployeeName)";

                    var parameters = new DynamicParameters();
                    parameters.Add("@Name", data.Name);
                    parameters.Add("@ComplaintReason", data.ComplaintReason);
                    parameters.Add("@EmployeeName", data.EmployeeName);


                    int rowsAffected = await conn.ExecuteAsync(query, parameters);
                    return rowsAffected.ToString();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Database error while adding complaint", ex);
            }
        }


        public async static Task<List<LoginModel>> GetComplaints()
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();
                    var employees = await conn.QueryAsync<LoginModel>("SELECT  t2.Username,    t1.ComplaintReason, t1.Name as ComplaintBy   FROM   Complaints t1 JOIN     Users t2 ON t1.EmployeeName = t2.UserId;");
                    return employees.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the employee list.", ex);
                }
            }
        }

        public async static Task<List<LoginModel>> GetComp(int userid)
        {
            using (SqlConnection conn = new SqlConnection("Server=MI01-D320\\SQLEXPRESS;Database=Hrms;Trusted_Connection=True;"))
            {
                try
                {
                    await conn.OpenAsync();

                    //var updateQuery = "SELECT * FROM Complaints WHERE EmployeeName = @userId";
                    var updateQuery = "SELECT     t1.*,     t2.Username FROM     Complaints t1  JOIN     Users t2 ON     t1.EmployeeName = t2.UserId WHERE   t1.EmployeeName = @userId;";

                    var result = await conn.QueryAsync<LoginModel>(updateQuery, new { userid = userid });

                    return result.ToList();
                }
                catch (Exception ex)
                {
                    throw new Exception("An error occurred while fetching the hike list.", ex);
                }
            }
        }
    }
}