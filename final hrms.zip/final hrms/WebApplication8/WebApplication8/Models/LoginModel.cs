﻿namespace WebApplication8.Models
{
    public class LoginModel
    {   
        public int UserId { get; set; }
        public string Role { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }  
        public string DateValue { get; set; }  
        public string HolidayName { get; set; } 
        public int Salary { get; set; }
        public string LeaveType { get; set; }
        public int Leave { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Reason { get; set; }
        public string Status { get; set; }
        public int LeaveApplyId { get; set; }
        public int PendingCount { get; set; }
        public bool visited { get; set; }   
        public string FirstName { get; set; }   
        public string LastName { get; set; }   
        public string Email{ get; set; }   
        public string PhoneNumber{ get; set; }   
        public string AuthorizeBy { get; set; }
        public int LogId { get; set; }
        public int OldSalary { get; set; }
        public int NewSalary { get; set; }
        public DateTime ChangeDate { get; set; }
        public string Manager { get; set; }
        public int TaskID { get; set; }
        public string TaskName { get; set; }
        public string EventDescription { get; set; }
        public string EventName { get; set; }
        public string Description { get; set; }
        public string UserStatus { get; set; }
        public string EmpName { get; set; }
        public string Name { get; set; }
        public string ComplaintReason { get; set; }
        public string ComplaintBy { get; set; }
        public string EmployeeName { get; set; }
        public DateTime HolidayDate { get; set; }
        public DateTime DueDate { get; set; }
    }
}